#include "mode_state.h"

SemiconductorSubMode semiconductorSubMode = SEMI_DIODE;
CapSubMode capSubMode = CAP_RANGE_NF;
OhmSubMode ohmSubMode = OHM_MAIN;
VdcSubMode vdcSubMode = VDC_MAIN;
VacSubMode vacSubMode = VAC_MAIN;
FreqSubMode freqSubMode = FREQ_MAIN;

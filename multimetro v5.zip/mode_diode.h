#ifndef MODE_DIODE_H
#define MODE_DIODE_H

// Función pública del submodo diodo
void measureDiode_Main(void);

#endif
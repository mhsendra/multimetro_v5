#ifndef INDUCT_H
#define INDUCT_H

// --- medición ---
float measureInductance_calibrated();

// --- API del modo ---
void measureInductanceMode();

#endif // INDUCT_H
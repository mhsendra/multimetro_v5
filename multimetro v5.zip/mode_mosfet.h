#ifndef MODE_MOSFET_H
#define MODE_MOSFET_H

// Función pública del submodo MOSFET
void measureMosfetMode(void);

#endif
#ifndef MODE_NCV_H
#define MODE_NCV_H

// Función pública del submodo NCV
void measureNCV(void);

#endif
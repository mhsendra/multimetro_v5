#ifndef AUTOOFF_H
#define AUTOOFF_H

void autoOff_reset();
void autoOff_activity();
void autoOff_update();

#endif

#ifndef MODE_TRANSISTOR_H
#define MODE_TRANSISTOR_H

// Función pública del submodo transistor
void measureTRANSISTOR(void);

#endif
#ifndef MODE_ZENER_H
#define MODE_ZENER_H

// Función pública del submodo Zener
void measureZENER_MODE(void);

#endif
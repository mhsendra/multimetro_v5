#ifndef MODE_DISPATCHERS_H
#define MODE_DISPATCHERS_H

#include "config.h"

void dispatchMode(MainMode selectedMode);
void resetModeState(MainMode mode);

#endif
#ifndef BACKLIGHT_H
#define BACKLIGHT_H

void backlight_reset();
void backlight_update();
void backlight_activity(); // NUEVA: para registrar actividad

#endif